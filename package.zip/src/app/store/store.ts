import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class StoreService {
    store: BehaviorSubject<any> = new BehaviorSubject<any>(null);
}