import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule,FormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { MaterialModule } from './material/material.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GenerateComponent } from './dashboard/generate/generate.component';
import { StoreService } from './store/store';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GenerateComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    MaterialModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
  ],
  providers: [StoreService],
  bootstrap: [AppComponent],
  entryComponents:[GenerateComponent]
})
export class AppModule { }
