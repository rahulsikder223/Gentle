import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/shared/notification.service';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroupService } from 'src/app/shared/form-group.service';
import { StoreService } from 'src/app/store/store';

@Component({
  selector: 'app-generate',
  templateUrl: './generate.component.html',
  styleUrls: ['./generate.component.css']
})
export class GenerateComponent implements OnInit {

  freuencyTypes: Array<any> = [
    { type: 'Daily' },
    { type: 'Weekly' },
    { type: 'Monthly' },
    { type: 'Yearly' },
    { type: 'One Time' },
  ];

  weeks: Array<any> = [
    { day: 'Mon' },
    { day: 'Tue' },
    { day: 'Wed' },
    { day: 'Thu' },
    { day: 'Fri' },
    { day: 'Sat' },
    { day: 'Sun' },
  ]

  months: Array<any> = [
    { month: 'Jan' },
    { month: 'Feb' },
    { month: 'Mar' },
    { month: 'Apr' },
    { month: 'May' },
    { month: 'Jun' },
    { month: 'Jul' },
    { month: 'Aug' },
    { month: 'Sep' },
    { month: 'Oct' },
    { month: 'Nov' },
    { month: 'Dec' },
  ]

  selectedType: string;
  ongoing: boolean = false;
  showOcuurences: boolean = false;
  disableOngoing: boolean = false;
  disableOccurences: boolean = false;

  constructor(private notificationService: NotificationService, public service: FormGroupService,
    public dialogRef: MatDialogRef<GenerateComponent>,
    private store: StoreService) { }

  ngOnInit() { }
  reset() {
    this.ongoing = false;
    this.showOcuurences = false;
    this.disableOngoing = false;
    this.disableOccurences = false;
  }
  onFrequencyChanged() {
    this.reset();
    this.service.form.reset();
  }
  checkOngoing(e) {
    this.ongoing = e.checked;
    this.disableOccurences = e.checked;
  }

  checkOccurence(e) {
    this.ongoing = e.checked;
    this.disableOngoing = e.checked;
    this.showOcuurences = e.checked;
  }

  onClear() {
    this.reset();
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.notificationService.success(':: Form Cleared');
  }

  onSubmit() {
    if (this.service.form.valid) {
      let responsePackage = {
        frequencyType : this.service.form.controls["frequencyType"].value,
        time : this.service.form.controls["time"].value,
        startDate : this.service.form.controls["startDate"].value,
        endDate : this.service.form.controls["endDate"].value,
        ongoing : this.service.form.controls["ongoing"].value,
        chooseOption : this.service.form.controls["chooseOption"].value,
        occurences : this.service.form.controls["occurences"].value,
        occurenceInput : this.service.form.controls["occurenceInput"].value
      };
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.notificationService.success(':: Submitted successfully');
      this.store.store.next(responsePackage);
      this.onClose();
    }
  }

  onClose() {
    this.reset();
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }


}
