import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { GenerateComponent } from './generate/generate.component';
import { FormGroupService } from '../shared/form-group.service';
import { StoreService } from '../store/store';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  time: any = [];
  constructor(private dialog: MatDialog, private service: FormGroupService, private store: StoreService) { }

  ngOnInit(): void {
    this.store.store.subscribe(x => {
      if (!!x) {
        this.time.push(x);
      }
    })
  }

  onGenerate() {
    this.service.initializeFormGroup();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(GenerateComponent, dialogConfig);
  }
}
