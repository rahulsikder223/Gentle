import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";

@Injectable({
  providedIn: 'root'
})
export class FormGroupService {

  constructor() { }

  form: FormGroup = new FormGroup({
    frequencyType: new FormControl('', Validators.required),
    time: new FormControl('', [Validators.required]),
    startDate: new FormControl('', [Validators.required]),
    endDate: new FormControl(''),
    ongoing: new FormControl(''),
    occurences: new FormControl(''),
    occurenceInput: new FormControl(''),
    chooseOption: new FormControl(''),
  });

  initializeFormGroup() {
    this.form.setValue({
        frequencyType: '',
        time: '',
        startDate: '',
        endDate: '',
        ongoing: '',
        occurences: '',
        occurenceInput: '',
        chooseOption: '',
    });
  }
}
