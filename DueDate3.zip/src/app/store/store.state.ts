import { Generate } from '../models/model';

export interface AppState {
  readonly generateDueDate: Generate[];
}

export interface HolidayState{
  readonly holiday: any[];
}