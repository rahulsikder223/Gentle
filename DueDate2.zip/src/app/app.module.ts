import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule,FormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { MaterialModule } from './material/material.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GenerateComponent } from './dashboard/generate/generate.component';
import { StoreModule } from '@ngrx/store';
import { generateDueDateReducer, generateHolidayReducer } from './store/store.reducer';
import { ManageHolidaysComponent } from './dashboard/manage-holidays/manage-holidays.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GenerateComponent,
    ManageHolidaysComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    MaterialModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({generateDueDate: generateDueDateReducer , holiday:generateHolidayReducer})
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents:[GenerateComponent , ManageHolidaysComponent]
})
export class AppModule { }
