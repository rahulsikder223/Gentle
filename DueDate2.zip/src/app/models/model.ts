export class Generate{
    frequencyType:string;
    time:string;
    startDate:any;
    endDate?:any;
    ongoing?:boolean;
    occurences?:boolean;
    occurenceInput?:string;
    chooseOption?:boolean;
    weeksDaysSelected?:Array<any>;
    monthsSelected?:Array<any>;
    yearlyOn?:string;
}