import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Store } from '@ngrx/store';
import { HolidayState } from 'src/app/store/store.state';

@Component({
  selector: 'app-manage-holidays',
  templateUrl: './manage-holidays.component.html',
  styleUrls: ['./manage-holidays.component.css']
})
export class ManageHolidaysComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ManageHolidaysComponent>, private store: Store<HolidayState>) { }
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  dates: Date[] = [];
  dateStrings = [];
  holidayDates = [];

  ngOnInit(): void {
    this.store.subscribe(x => {
      if (!!x) {
        this.dates = [];
        this.dateStrings = [];
        this.holidayDates = x.holiday;

        for (let i = 0; i < this.holidayDates.length; i++) {
          for (var p in this.holidayDates[i]) {
            this.dates.push(new Date(this.holidayDates[i][p]));
            this.dateStrings.push(new Date(this.holidayDates[i][p]).toDateString());
          }
        }
      }
    });
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = new Date(event.value);

    if (!!value) {
      this.dates.push(value);
      this.dateStrings.push(value.toDateString());
    }

    if (input) {
      input.value = '';
    }

  }

  remove(date: any): void {
    const index = this.dates.indexOf(date);

    if (index >= 0) {
      this.dates.splice(index, 1);
    }
  }

  onClose() {
    this.store.dispatch({
      type: 'HOLIDAYS',
      payload: { ...this.dates }
    });
    this.dialogRef.close();
  }
}
