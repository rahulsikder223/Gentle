import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/shared/notification.service';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroupService } from 'src/app/shared/form-group.service';
import * as _moment from 'moment';
import { Generate } from 'src/app/models/model';
import { Store } from '@ngrx/store';
import { AppState, HolidayState } from 'src/app/store/store.state';

const moment = _moment;
@Component({
  selector: 'app-generate',
  templateUrl: './generate.component.html',
  styleUrls: ['./generate.component.css']
})
export class GenerateComponent implements OnInit {

  freuencyTypes: Array<any> = [
    { type: 'Daily' },
    { type: 'Weekly' },
    { type: 'Monthly' },
    { type: 'Yearly' },
    { type: 'One Time' },
  ];

  weeks: Array<any> = [
    { day: 'Mon', index: 1 },
    { day: 'Tue', index: 2 },
    { day: 'Wed', index: 3 },
    { day: 'Thu', index: 4 },
    { day: 'Fri', index: 5 }
  ]

  months: Array<any> = [
    { month: 'Jan' },
    { month: 'Feb' },
    { month: 'Mar' },
    { month: 'Apr' },
    { month: 'May' },
    { month: 'Jun' },
    { month: 'Jul' },
    { month: 'Aug' },
    { month: 'Sep' },
    { month: 'Oct' },
    { month: 'Nov' },
    { month: 'Dec' },
  ]

  selectedType: string;
  ongoing: boolean = false;
  showOcuurences: boolean = false;
  disableOngoing: boolean = false;
  disableOccurences: boolean = false;
  saveForm: Array<Generate> = [];
  submitSuccessfully: boolean = false;
  // holidayDates: Observable<any>;
  holidayDates: any[] = [];
  weeksDaysSelected: any[] = [];
  monthsSelected: any[] = [];
  yearlyOn: string;
  maxDate: any;

  constructor(private notificationService: NotificationService, public service: FormGroupService,
    public dialogRef: MatDialogRef<GenerateComponent>, private storeHoliday: Store<HolidayState>,
    private store: Store<AppState>) {
    this.storeHoliday.subscribe(x => {
      if (!!x) {
        this.holidayDates = x.holiday;
      }
    });
  }

  ngOnInit() { }
  reset() {
    this.ongoing = false;
    this.showOcuurences = false;
    this.disableOngoing = false;
    this.disableOccurences = false;
    this.selectedType = "";
  }
  onFrequencyChanged() {
    this.reset();
    this.service.form.reset();
  }
  checkOngoing(e) {
    this.ongoing = e.checked;
    this.disableOccurences = e.checked;
  }

  weekValues(day, checked) {
    if (checked) {
      this.weeksDaysSelected.push(day);
    }
    if (!checked && !!this.weeksDaysSelected && this.weeksDaysSelected.includes(day)) {
      const index = this.weeksDaysSelected.indexOf(day);
      if (index > -1) {
        this.weeksDaysSelected.splice(index, 1);
      }
    }
  }

  monthValues(month, checked) {
    if (checked) {
      this.monthsSelected.push(month);
    }
    if (!checked && !!this.monthsSelected && this.monthsSelected.includes(month)) {
      const index = this.monthsSelected.indexOf(month);
      if (index > -1) {
        this.monthsSelected.splice(index, 1);
      }
    }
  }

  yearValue(event) {
    this.yearlyOn = event.value.month;
  }

  checkOccurence(e) {
    this.ongoing = e.checked;
    this.disableOngoing = e.checked;
    this.showOcuurences = e.checked;
  }

  onClear() {
    this.reset();
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.notificationService.success(':: Form Cleared');
  }
  clean(obj: any) {
    for (var propName in obj) {
      if (obj[propName] === null || obj[propName] === undefined || obj[propName] === "") {
        delete obj[propName];
      }
    }
    return obj;
  }
  validateHolidays() {
    this.saveForm = [];
    if (this.service.form.value["ongoing"] || this.service.form.value["occurences"])
      this.service.form.value["endDate"] = "";
    this.saveForm = { ...(this.clean(this.service.form.value)) };
    let startDate = this.saveForm["startDate"];
    let endDate = this.saveForm["endDate"];

    let isHoliday = false;
    if (this.holidayDates.length > 0) {
      for (let i = 0; i < this.holidayDates.length; i++) {
        for (var p in this.holidayDates[i]) {
          if (new Date(this.holidayDates[i][p]).toDateString() == this.saveForm["startDate"].toDateString()) {
            isHoliday = true;
            this.submitSuccessfully = false;
            this.notificationService.warn(':: Holidays cannot be start due date');
            break;
          }
        }
      }

      for (let i = 0; i < this.holidayDates.length; i++) {
        for (var p in this.holidayDates[i]) {
          if (!!this.saveForm["endDate"] && new Date(this.holidayDates[i][p]).toDateString() == this.saveForm["endDate"].toDateString()) {
            isHoliday = true;
            this.submitSuccessfully = false;
            this.notificationService.warn(':: Holidays cannot be end due date');
            break;
          }
        }
      }
    }

    if (this.saveForm["ongoing"] && this.saveForm["startDate"] > new Date()) {
      this.submitSuccessfully = false;
      isHoliday = true;
      this.notificationService.warn(':: Start due date of an ongoing process cannot be greater than current date');
    }

    let dailyEndDay = this.saveForm["endDate"] != null ? this.saveForm["endDate"].getDay() : null;
    let dailyStartDay = this.saveForm["startDate"].getDay();
    if (dailyStartDay != null && dailyEndDay != null && (dailyStartDay == 0 || dailyStartDay == 6 || dailyEndDay == 0 || dailyEndDay == 6) && !isHoliday) {
      this.submitSuccessfully = false;
      isHoliday = true;
      this.notificationService.warn(':: Weekends cannot be start or end due date');
    }

    if (startDate != null && endDate != null && (startDate.getYear() >= endDate.getYear()) && (startDate.getMonth() >= endDate.getMonth()) && startDate.getDate() > endDate.getDate()) {
      isHoliday = true;
      this.submitSuccessfully = false;
      this.notificationService.warn(':: End due date must be after start due date');
    }
    if (!isHoliday) {
      this.submitSuccessfully = true;
    }
  }
  onSubmit() {
    this.saveForm = [];

    switch (this.selectedType) {
      case "One Time":
        this.saveForm = [];
        this.saveForm = { ...(this.clean(this.service.form.value)) };
        let day = this.saveForm["startDate"].getDay();

        let isHoliday = false;
        if (this.holidayDates.length > 0) {
          for (let i = 0; i < this.holidayDates.length; i++) {
            for (var p in this.holidayDates[i]) {
              if (new Date(this.holidayDates[i][p]).toDateString() == this.saveForm["startDate"].toDateString()) {
                isHoliday = true;
                this.submitSuccessfully = false;
                this.notificationService.warn(':: Holidays cannot be due date');
                break;
              }
            }
          }
        }

        if ((day == 0 || day == 6) && !isHoliday) {
          this.submitSuccessfully = false;
          this.notificationService.warn(':: Weekends cannot be due date');
        }
        else if (!isHoliday) {
          this.submitSuccessfully = true;
        }
        break;
      default:
        this.validateHolidays();
    }
    if (this.submitSuccessfully) {
      !!this.saveForm && this.store.dispatch({
        type: 'GENERATE_DUE_DATE',
        payload: { ...this.saveForm, weeksDaysSelected: this.weeksDaysSelected, monthsSelected: this.monthsSelected, yearlyOn: this.yearlyOn }
      });
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.notificationService.success(':: Submitted successfully');
      this.onClose();
    }
  }

  onClose() {
    this.reset();
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }


}
