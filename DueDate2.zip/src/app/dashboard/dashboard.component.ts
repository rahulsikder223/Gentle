import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { GenerateComponent } from './generate/generate.component';
import { FormGroupService } from '../shared/form-group.service';
import { Store } from '@ngrx/store';
import { AppState, HolidayState } from '../store/store.state';
import { Observable } from 'rxjs';
import { Generate } from '../models/model';
import { ManageHolidaysComponent } from './manage-holidays/manage-holidays.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  allDates: any;
  holidayDates: any[] = [];
  allWorkingDates: any;
  allWorkingWeeklyDates = [];
  generatedDates: any;
  dailyTime: any;
  weeklyTime: any;
  weekdaysList = [];

  oneTimeGeneratedDates: Array<Generate>;
  dailyGeneratedDates: Array<Generate>;
  monthlyGeneratedDates: Array<Generate>;
  weeklyGeneratedDates: Array<Generate>;
  yearlyGeneratedDates: Array<Generate>;

  constructor(private dialog: MatDialog, private service: FormGroupService, private store: Store<AppState>, private storeHoliday: Store<HolidayState>, ) {
    this.storeHoliday.subscribe(x => {
      if (!!x) {
        this.holidayDates = x.holiday;
      }
    });
    this.store.subscribe(s => {
      if (s.generateDueDate != null) {
        this.generatedDates = s.generateDueDate;
        this.oneTimeGeneratedDates = s.generateDueDate.filter(x =>
          !!x.frequencyType && x.frequencyType.toLowerCase() == "one time"
        );
        this.dailyGeneratedDates = [...s.generateDueDate.filter(x =>
          x.frequencyType.toLowerCase() == "daily"
        )];

        if (this.dailyGeneratedDates != null && this.dailyGeneratedDates.length > 0) {
          this.dailyGeneratedDates.forEach(x => {
            this.allDates = this.getDateArray(x.startDate, x.endDate, x.occurenceInput, "daily");
            this.dailyTime = x.time;
            this.allWorkingDates = this.getWorkingDateArray(this.allDates);
          });
        }

        this.monthlyGeneratedDates = s.generateDueDate.filter(x => { !!x.frequencyType && x.frequencyType.toLowerCase() == "monthly" }
        );
        this.weeklyGeneratedDates = [...s.generateDueDate.filter(x =>
          x.frequencyType.toLowerCase() == "weekly"
        )];

        if (this.weeklyGeneratedDates != null && this.weeklyGeneratedDates.length > 0) {
          this.weeklyGeneratedDates.forEach(x => {
            this.weekdaysList = x.weeksDaysSelected;
            let allWeeklyDates = this.getDateArray(x.startDate, x.endDate, x.occurenceInput, "weekly");
            this.weeklyTime = x.time;
            this.allWorkingWeeklyDates = this.getWorkingDateArray(allWeeklyDates);
          });
        }

        this.yearlyGeneratedDates = s.generateDueDate.filter(x => { !!x.frequencyType && x.frequencyType.toLowerCase() == "yearly" }
        );
      }
    });
  }
  displayedColumns: string[] = ['startDate', 'time'];
  ngOnInit(): void {
  }

  formatDate(date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('-');
  }

  getDateArray = function (start, end, occurences, frequency) {
    var arr = new Array(),
      dt = new Date(start);

    if (frequency == "daily") {
      let i = 0;
      while ((dt <= (end != null ? end : new Date()) && occurences == null) || (occurences != null && i++ < parseInt(occurences))) {
        arr.push(new Date(dt));
        dt.setDate(dt.getDate() + 1);
      }
    }
    else if (frequency == "weekly") {
      let i = 0;
      while ((dt <= (end != null ? end : new Date()) && occurences == null) || (occurences != null && i++ < parseInt(occurences))) {
        if (this.weekdaysList.filter(x => x == dt.toDateString().split(" ")[0]).length > 0) {
          arr.push(new Date(dt));
        }
        dt.setDate(dt.getDate() + 1);
      }
    }

    return arr;
  }

  getWorkingDateArray(dates) {
    // Remove the weekends...
    var weekdays = [...dates.filter(x => x.getDay() != 0 && x.getDay() != 6)];

    // remove holidays
    var holidays = [];
    for (let i = 0; i < this.holidayDates.length; i++) {
      for (var p in this.holidayDates[i]) {
        holidays.push(new Date(this.holidayDates[i][p]).toDateString());
      }
    }
    var weekWorkingDates = weekdays.map(x => x.toDateString());
    var result = weekWorkingDates.filter(date => holidays.indexOf(date) < 0);
    var finalResult = result.map(x => new Date(x));

    return finalResult;
  }

  onGenerate() {
    this.service.initializeFormGroup();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(GenerateComponent, dialogConfig);
  }
  manageHolidays() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(ManageHolidaysComponent, dialogConfig);
  }
}
