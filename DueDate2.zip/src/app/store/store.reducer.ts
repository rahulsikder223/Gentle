import { Generate } from '../models/model';

export const GENERATE_DUE_DATE = 'GENERATE_DUE_DATE';
export const HOLIDAYS = 'HOLIDAYS';

export function generateDueDateReducer(state: any[] = [], action) {
    switch (action.type) {
        case GENERATE_DUE_DATE:
            return [...state, action.payload];
        default:
            return state;
    }
}

export function generateHolidayReducer(state: any[] = [], action) {
    switch (action.type) {
        case HOLIDAYS:
            return [...state, action.payload];
        default:
            return state;
    }
}