AudioFile
=========

.. automodule:: aeneas.audiofile
    :members:
