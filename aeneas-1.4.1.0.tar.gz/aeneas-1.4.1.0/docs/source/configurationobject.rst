ConfigurationObject
===================

.. automodule:: aeneas.configurationobject
    :members:
