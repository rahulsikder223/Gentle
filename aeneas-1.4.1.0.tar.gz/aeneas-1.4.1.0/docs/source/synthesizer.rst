Synthesizer
===========

.. automodule:: aeneas.synthesizer
    :members:
