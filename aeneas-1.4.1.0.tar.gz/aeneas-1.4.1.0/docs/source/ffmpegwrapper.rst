FFMPEGWrapper
=============

.. automodule:: aeneas.ffmpegwrapper
    :members:
