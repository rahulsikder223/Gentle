AnalyzeContainer
================

.. automodule:: aeneas.analyzecontainer
    :members:
