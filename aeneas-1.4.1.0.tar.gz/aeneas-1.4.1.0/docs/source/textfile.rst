TextFile
========

.. automodule:: aeneas.textfile
    :members:
