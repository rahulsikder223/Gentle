ESPEAKWrapper
=============

.. automodule:: aeneas.espeakwrapper
    :members:
