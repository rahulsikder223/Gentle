HierarchyType
=============

.. automodule:: aeneas.hierarchytype
    :members:
