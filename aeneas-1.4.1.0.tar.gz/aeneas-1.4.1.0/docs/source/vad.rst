VAD
===

.. automodule:: aeneas.vad
    :members:
