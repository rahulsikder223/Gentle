Global functions (globalfunctions)
==================================

.. automodule:: aeneas.globalfunctions
    :members:
