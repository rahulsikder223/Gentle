FFPROBEWrapper
==============

.. automodule:: aeneas.ffprobewrapper
    :members:
