IDSortingAlgorithm
==================

.. automodule:: aeneas.idsortingalgorithm
    :members:
