Global constants (globalconstants)
==================================

.. automodule:: aeneas.globalconstants
    :members:
