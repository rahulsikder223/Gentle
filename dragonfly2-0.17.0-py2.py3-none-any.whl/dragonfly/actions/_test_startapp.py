﻿

from dragonfly import *

#StartApp(r"c:\Windows\system32\notepad.exe").execute()
#StartApp(r"%SystemRoot%\system32\notepad.exe").execute()
#

#BringApp(r"c:\Windows\system32\notepad.exe").execute()
BringApp("winword").execute()

