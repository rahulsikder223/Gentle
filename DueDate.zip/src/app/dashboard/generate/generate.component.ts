import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/shared/notification.service';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroupService } from 'src/app/shared/form-group.service';
import * as _moment from 'moment';
import { Generate } from 'src/app/models/model';
import { Store } from '@ngrx/store';
import { AppState, HolidayState } from 'src/app/store/store.state';
import { Observable } from 'rxjs';

const moment = _moment;
@Component({
  selector: 'app-generate',
  templateUrl: './generate.component.html',
  styleUrls: ['./generate.component.css']
})
export class GenerateComponent implements OnInit {

  freuencyTypes: Array<any> = [
    { type: 'Daily' },
    { type: 'Weekly' },
    { type: 'Monthly' },
    { type: 'Yearly' },
    { type: 'One Time' },
  ];

  weeks: Array<any> = [
    { day: 'Mon' },
    { day: 'Tue' },
    { day: 'Wed' },
    { day: 'Thu' },
    { day: 'Fri' },
    { day: 'Sat' },
    { day: 'Sun' },
  ]

  months: Array<any> = [
    { month: 'Jan' },
    { month: 'Feb' },
    { month: 'Mar' },
    { month: 'Apr' },
    { month: 'May' },
    { month: 'Jun' },
    { month: 'Jul' },
    { month: 'Aug' },
    { month: 'Sep' },
    { month: 'Oct' },
    { month: 'Nov' },
    { month: 'Dec' },
  ]

  selectedType: string;
  ongoing: boolean = false;
  showOcuurences: boolean = false;
  disableOngoing: boolean = false;
  disableOccurences: boolean = false;
  saveForm: Array<Generate> = [];
  submitSuccessfully: boolean = false;
  // holidayDates: Observable<any>;
  holidayDates: any[] = [];

  constructor(private notificationService: NotificationService, public service: FormGroupService,
    public dialogRef: MatDialogRef<GenerateComponent>, private storeHoliday: Store<HolidayState>,
    private store: Store<AppState>) {
    this.storeHoliday.subscribe(x => {
      if (!!x) {
        this.holidayDates = x.generateDueDate;
      }
    });
  }

  ngOnInit() { }
  reset() {
    this.ongoing = false;
    this.showOcuurences = false;
    this.disableOngoing = false;
    this.disableOccurences = false;
    this.selectedType = "";
  }
  onFrequencyChanged() {
    this.reset();
    this.service.form.reset();
  }
  checkOngoing(e) {
    this.ongoing = e.checked;
    this.disableOccurences = e.checked;
  }

  checkOccurence(e) {
    this.ongoing = e.checked;
    this.disableOngoing = e.checked;
    this.showOcuurences = e.checked;
  }

  onClear() {
    this.reset();
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.notificationService.success(':: Form Cleared');
  }
  clean(obj) {
    for (var propName in obj) {
      if (obj[propName] === null || obj[propName] === undefined || obj[propName] === "") {
        delete obj[propName];
      }
    }
    return obj;
  }
  onSubmit() {
    this.saveForm = [];

    switch (this.selectedType) {
      case "Daily": this.saveForm = [];
      this.saveForm = { ...(this.clean(this.service.form.value)) };

      let isAHoliday = false;
      for (var p in this.holidayDates[0]) {
        if (new Date(this.holidayDates[0][p].date).toDateString() == this.saveForm["startDate"].toDateString()) {
          isAHoliday = true;
          this.submitSuccessfully = false;
          this.notificationService.warn(':: Holidays cannot be due date');
          break;
        }
      }

      if ((this.saveForm["startDate"].getDay() == 0 || this.saveForm["startDate"].getDay() == 6) && !isAHoliday) {
        this.submitSuccessfully = false;
        this.notificationService.warn(':: Weekends cannot be due date');
      }
      else if (!isAHoliday) {
        this.submitSuccessfully = true;
      }
        break;
      case "Weekly": console.log(this.service.form.value);
        break;
      case "Monthly": console.log(this.service.form.value);
        break;
      case "Yearly": console.log(this.service.form.value);
        break;
      case "One Time":
        this.saveForm = [];
        this.saveForm = { ...(this.clean(this.service.form.value)) };
        let day = this.saveForm["startDate"].getDay();

        let isHoliday = false;
        for (var p in this.holidayDates[0]) {
          if (new Date(this.holidayDates[0][p].date).toDateString() == this.saveForm["startDate"].toDateString()) {
            isHoliday = true;
            this.submitSuccessfully = false;
            this.notificationService.warn(':: Holidays cannot be due date');
            break;
          }
        }

        if ((day == 0 || day == 6) && !isHoliday) {
          this.submitSuccessfully = false;
          this.notificationService.warn(':: Weekends cannot be due date');
        }
        else if (!isHoliday) {
          this.submitSuccessfully = true;
        }
        break;
    }
    if (this.submitSuccessfully) {
      !!this.saveForm && this.store.dispatch({
        type: 'GENERATE_DUE_DATE',
        payload: { ...this.saveForm }
      });
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.notificationService.success(':: Submitted successfully');
      this.onClose();
    }
  }

  onClose() {
    this.reset();
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }


}
