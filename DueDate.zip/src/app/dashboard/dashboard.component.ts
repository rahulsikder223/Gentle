import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { GenerateComponent } from './generate/generate.component';
import { FormGroupService } from '../shared/form-group.service';
import { Store } from '@ngrx/store';
import { AppState } from '../store/store.state';
import { Observable } from 'rxjs';
import { Generate } from '../models/model';
import { ManageHolidaysComponent } from './manage-holidays/manage-holidays.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  generatedDates: Observable<Generate[]>;

  oneTimeGeneratedDates: Array<Generate>;
  dailyGeneratedDates: Array<Generate>;

  constructor(private dialog: MatDialog, private service: FormGroupService, private store: Store<AppState>) {
    this.generatedDates = this.store.select(state => state.generateDueDate);
    this.generatedDates.subscribe(s => {
      if (s != null) {
        this.oneTimeGeneratedDates = s.filter(x => x.frequencyType.toLowerCase() == "one time");
        this.dailyGeneratedDates = s.filter(x => x.frequencyType.toLowerCase() == "daily");
      }
    });
  }
  displayedColumns: string[] = ['startDate', 'time'];
  ngOnInit(): void {
  }

  onGenerate() {
    this.service.initializeFormGroup();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(GenerateComponent, dialogConfig);
  }
  manageHolidays() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(ManageHolidaysComponent, dialogConfig);
  }
}
