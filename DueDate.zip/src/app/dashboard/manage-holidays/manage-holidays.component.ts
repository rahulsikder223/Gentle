import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatChipInputEvent } from '@angular/material/chips';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { Store } from '@ngrx/store';
import { HolidayState } from 'src/app/store/store.state';

@Component({
  selector: 'app-manage-holidays',
  templateUrl: './manage-holidays.component.html',
  styleUrls: ['./manage-holidays.component.css']
})
export class ManageHolidaysComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ManageHolidaysComponent>, private store: Store<HolidayState>) { }
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  dates: any[] = [
    {date: '2020-12-11'},
    {date: '2020-06-23'},
    {date: '2020-03-11'},
  ];

  ngOnInit(): void {
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if ((value || '').trim()) {
      this.dates.push({date: value.trim()});
    }

    if (input) {
      input.value = '';
    }
    
  }

  remove(date: any): void {
    const index = this.dates.indexOf(date);

    if (index >= 0) {
      this.dates.splice(index, 1);
    }
  }

  onClose() {
    this.store.dispatch({
      type: 'HOLIDAYS',
      payload: { ...this.dates }
    });
    this.dialogRef.close();
  }
}
