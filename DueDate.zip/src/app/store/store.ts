import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class StoreService {
    private _store: Map<string, BehaviorSubject<any>> = new Map();

    public getFromStore(obj: any): Observable<any> {
        for (var key in obj) {
            return this._store.get(key) ? this._store.get(key).asObservable() : null;
        }

    }

    public setInStore(obj:any) {
        for (var key in obj) {
            let value = obj[key];
        if (!this._store.has(key)) {
            this._store.set(key, new BehaviorSubject<any>(value));
        }
        else {
            this._store.get(key).next(value);
        }
    }
    }
}