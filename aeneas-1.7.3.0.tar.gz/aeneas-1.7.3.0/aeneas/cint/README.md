# aeneas.cint

This directory contains portable
fixed-size int type definitions and functions
for the other Python C extensions.

