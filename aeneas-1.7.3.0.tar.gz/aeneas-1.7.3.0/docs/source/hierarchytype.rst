hierarchytype
=============

.. automodule:: aeneas.hierarchytype
    :members:
