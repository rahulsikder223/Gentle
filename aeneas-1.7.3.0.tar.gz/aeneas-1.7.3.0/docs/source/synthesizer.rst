synthesizer
===========

.. automodule:: aeneas.synthesizer
    :members:
