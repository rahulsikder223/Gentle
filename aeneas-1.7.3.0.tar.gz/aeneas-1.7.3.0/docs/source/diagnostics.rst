diagnostics
===========

.. automodule:: aeneas.diagnostics
    :members:
