ffprobewrapper
==============

.. automodule:: aeneas.ffprobewrapper
    :members:
