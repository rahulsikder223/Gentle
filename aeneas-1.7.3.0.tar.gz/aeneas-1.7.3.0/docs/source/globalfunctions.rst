globalfunctions
===============

.. automodule:: aeneas.globalfunctions
    :members:
