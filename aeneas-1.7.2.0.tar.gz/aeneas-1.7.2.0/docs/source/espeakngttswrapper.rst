espeakngttswrapper
==================

.. automodule:: aeneas.ttswrappers.espeakngttswrapper
    :members:
