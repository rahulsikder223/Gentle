## Environment details

- OS:
- OS version:
- node-pty version:

## Issue description

